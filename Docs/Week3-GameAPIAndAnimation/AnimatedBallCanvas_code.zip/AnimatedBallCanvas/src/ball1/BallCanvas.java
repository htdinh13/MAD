/*
 *  Copyright 2011 RMIT International University Vietnam
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package ball1;

import javax.microedition.lcdui.game.GameCanvas;

/**
 * Extends the standard MIDP library's GameCanvas with an animation loop.
 * @author Barend Scholtus
 */
class BallCanvas extends GameCanvas implements Runnable {

    // the Thread running the gameloop in the background
    // volatile to ensure integrity of the value across multiple threads
    private volatile Thread runner;

    /**
     * Creates a new BallCanvas that runs the main gameloop in a thread.
     */
    public BallCanvas() {
        super(false);
    }

    /**
     * Start a new thread that runs the main gameloop.
     */
    public void start() {
        runner = new Thread(this);
        runner.start();
    }

    /**
     * Causes the main gameloop to end after completing a frame.
     */
    public void stop() {
        runner = null;
    }

    /**
     * Runs the main gameloop after a call to start(), and until stop() is
     * called.
     */
    public void run() {
        while (Thread.currentThread() == runner) {
            // main gameloop here
        }
    }
}
