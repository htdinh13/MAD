/*
 *  Copyright 2011 RMIT International University Vietnam
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package ball2;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;

/**
 * Extends the standard MIDP library's GameCanvas with an animation loop.
 * @author Barend Scholtus
 */
class BallCanvas extends GameCanvas implements Runnable {

    // the Thread running the gameloop in the background
    // volatile to ensure integrity of the value across multiple threads
    private volatile Thread runner;

    // the ball location and speed
    private BallModel model;

    /**
     * Creates a new BallCanvas that runs the main gameloop in a thread.
     */
    public BallCanvas(BallModel model) {
        super(true);
        this.model = model;
    }

    /**
     * Start a new thread that runs the main gameloop.
     */
    public void start() {
        runner = new Thread(this);
        runner.start();
    }

    /**
     * Causes the main gameloop to end after completing a frame.
     */
    public void stop() {
        runner = null;
    }

    /**
     * Runs the main gameloop after a call to start(), and until stop() is
     * called.
     */
    public void run() {
        Graphics g = getGraphics();
        while (Thread.currentThread() == runner) {
            handleInput();
            gameUpdate();
            doPaint(g);
            flushGraphics();

            try {
                Thread.sleep(15);
            } catch (Exception e) { /* ignored */ }
        }
    }

    /**
     * Uses the low-level API for getting input.
     */
    private void handleInput() {
        int keyState = getKeyStates();
        if ((keyState & UP_PRESSED) != 0) {
            model.up();
        } else if ((keyState & DOWN_PRESSED) != 0) {
            model.down();
        } else if ((keyState & LEFT_PRESSED) != 0) {
            model.left();
        } else if ((keyState & RIGHT_PRESSED) != 0) {
            model.right();
        }
    }

    /**
     * Performs 1 game state/physics update.
     */
    private void gameUpdate() {
        model.step();
    }

    /**
     * Performs rendering on the given Graphics object.
     * @param g the rendering context
     */
    private void doPaint(Graphics g) {

        // erase the background
        g.setColor(0);
        g.fillRect(0, 0, getWidth(), getHeight());

        // draw the ball
        g.setColor(0xFFFFFF);
        g.fillRect(model.getX()-1, model.getY()-1, 3, 3);
    }
}
