/*
 *  Copyright 2011 RMIT International University Vietnam
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package ball3;

import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;

/**
 *
 * @author Barend Scholtus
 */
class BallModel {

    private MIDlet midlet;
    private Displayable disp;
    private int width;
    private int height;

    private int x;
    private int y;
    private int dx;
    private int dy;

    public BallModel(MIDlet midlet) {
        this.midlet = midlet;
        init();
    }

    private void init() {
        disp = Display.getDisplay(midlet).getCurrent();
        if (disp != null) {
            width = disp.getWidth();
            height = disp.getHeight();
            x = width/2;
            y = height/2;
            dx = 1;
            dy = 2;
        }
    }

    public void step() {
        if (disp == null) {
            init();
        }

        x += dx;
        if (x < 0) {
            x = -x;
            dx = -dx;
        } else if (x >= width) {
            x = 2 * (width-1) - x;
            dx = -dx;
        }

        y += dy;
        if (y < 0) {
            y = -y;
            dy = -dy;
        } else if (y >= height) {
            y = 2 * (height-1) - y;
            dy = -dy;
        }
    }

    public void up() {
        dy--;
    }

    public void down() {
        dy++;
    }

    public void left() {
        dx--;
    }

    public void right() {
        dx++;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
