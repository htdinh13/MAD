Upload the server side scripts to php5 enabled web - server. 

highscore.xml - scores are stored in xml file
save.php      - saves given name, score and location to highscore.xml
showall.php   - shows the highscore in plain text and in order
totext.xslt   - xslt transformation file for transforming the xml file
                to plain text
                