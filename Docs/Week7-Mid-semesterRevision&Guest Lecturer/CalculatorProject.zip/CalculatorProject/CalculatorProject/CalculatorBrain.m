//
//  CalculatorBrain.m
//  CalculatorProject
//
//  Created by Gia on 7/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CalculatorBrain.h"

@implementation CalculatorBrain

- (void)setOperand:(double)_operand{
    operand = _operand;
}

- (void)performWaitingOperation
{
    if ([@"+" isEqual:waitingOperation]){
        operand = waitingOperand + operand;
    }
    else if ([@"*" isEqual:waitingOperation]){
        operand = waitingOperand * operand;
    }
    else if ([@"-" isEqual:waitingOperation]){
        operand = waitingOperand - operand;
    }
    else if ([@"/" isEqual:waitingOperation]){
        if (operand) {
            operand = waitingOperand / operand;
        }
    }
}

- (double)performOperation:(NSString *)operation{
    [self performWaitingOperation];
    
    waitingOperand =operand;
    waitingOperation = operation;
    
    return operand;
}


@end
