//
//  CalculatorViewController.m
//  CalculatorProject
//
//  Created by Gia on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CalculatorViewController.h"

@interface CalculatorViewController ()

@end

@implementation CalculatorViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#define POSITION_X 30
#define POSITION_Y 100

#define DISTANCE_WIDTH 70
#define DISTANCE_HEIGHT 55

- (void)digitPress:(UIButton *)sender{
    NSString *digit = sender.titleLabel.text;
    
    if (userIsInTheMiddleOfTypingNumber) {
        display.text = [display.text stringByAppendingString:digit];
    }else {
        display.text = digit;
        userIsInTheMiddleOfTypingNumber = YES;
    }
    
}

- (void)operatorPress:(UIButton *)sender{
    if (userIsInTheMiddleOfTypingNumber) {
        userIsInTheMiddleOfTypingNumber = NO;
        [brain setOperand:display.text.doubleValue];
        
        
    }
    display.text = [NSString stringWithFormat:@"%g",[brain performOperation:sender.titleLabel.text]];
    
    [brain setOperand:display.text.doubleValue];
}

- (CalculatorBrain *)brain{
    if (!brain) {
        brain = [[CalculatorBrain alloc] init];
    }
    return brain;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    brain = [[CalculatorBrain alloc] init];
    userIsInTheMiddleOfTypingNumber = NO;
    
    // Do any additional setup after loading the view from its nib.
    int x = POSITION_X;
    int y = POSITION_Y;
    
    for (int i = 1; i<10; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        btn.frame = CGRectMake(x, y, 64, 44);
        [btn setTitle:[NSString stringWithFormat:@"%d",i] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(digitPress:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
        
        x += DISTANCE_WIDTH;
        if (x > 210) {
            x = POSITION_X;
            y += DISTANCE_HEIGHT;
        }
    }
    
    
    
    display = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 300, 44)];
    display.backgroundColor = [UIColor lightGrayColor];
    display.textAlignment = UITextAlignmentRight;
    display.text = @"display";
    [self.view addSubview:display];
    
    
    /*
     operation
     */
    x = POSITION_X + DISTANCE_WIDTH*3;
    y = POSITION_Y;
    
    NSArray *operators = [NSArray arrayWithObjects:@"+",@"-",@"*",@"/",@"=", nil];
    
    for (int i = 0; i < [operators count]; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        btn.frame = CGRectMake(x, y, 64, 44);
        [btn setTitle:[operators objectAtIndex:i] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(operatorPress:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
        
        
        y += DISTANCE_HEIGHT;
        
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
