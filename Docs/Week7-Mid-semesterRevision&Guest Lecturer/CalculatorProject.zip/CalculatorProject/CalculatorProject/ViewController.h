//
//  ViewController.h
//  CalculatorProject
//
//  Created by Gia on 7/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CalculatorBrain.h"


@protocol a
    


@end

@interface ViewController:UIViewController{
    @private
    CalculatorBrain *brain;
    IBOutlet UILabel *display;
}



- (IBAction)operationPress:(id)sender;
- (IBAction)digitPress:(id)sender;
@end
