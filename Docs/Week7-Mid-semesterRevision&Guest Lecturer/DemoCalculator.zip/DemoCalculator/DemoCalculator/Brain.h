//
//  Brain.h
//  DemoCalculator
//
//  Created by Gia on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Brain : NSObject{
    double firstOperand;
    double operand;
    NSString *operation;
}

@property (nonatomic) double operand;

- (double)performCalculation:(NSString *)operation;

@end
