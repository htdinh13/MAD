//
//  Brain.m
//  DemoCalculator
//
//  Created by Gia on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Brain.h"

@implementation Brain

@synthesize operand;

- (double)actualCalculating{
    if ([operation isEqualToString:@"+"]) {
        return firstOperand + operand;
    }else {
        
    }
    
    return operand;
}


- (double)performCalculation:(NSString *)anOperation{
    operand = [self actualCalculating];
    
    firstOperand = operand;
    operation = anOperation;
    
    return operand;
}

@end
