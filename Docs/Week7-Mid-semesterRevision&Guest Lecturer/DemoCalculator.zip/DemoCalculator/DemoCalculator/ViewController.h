//
//  ViewController.h
//  DemoCalculator
//
//  Created by Gia on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Brain.h"

@interface ViewController : UIViewController{
    UILabel *display;
    Brain *brain;
    BOOL isInMiddleOfInputNumber;
    
    IBOutlet UIButton *ibButton;
    
    
}

@property (nonatomic, retain) IBOutlet UIButton *ibButton;

- (IBAction)digitPress:(UIButton *)sender;

@end
