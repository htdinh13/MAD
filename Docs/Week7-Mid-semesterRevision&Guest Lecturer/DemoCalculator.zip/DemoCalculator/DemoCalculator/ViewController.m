//
//  ViewController.m
//  DemoCalculator
//
//  Created by Gia on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize ibButton;
#define X_POSITION 20
#define Y_POSITION 100
#define DISTANCE_X 75
#define DISTANCE_Y 55



- (void)operationPress:(UIButton *)sender{
    [brain setOperand:display.text.doubleValue];
    
    double result = [brain performCalculation:sender.titleLabel.text];
    
    display.text = [NSString stringWithFormat:@"%g",result];
    isInMiddleOfInputNumber = NO;
    
}


- (IBAction)digitPress:(UIButton *)sender{
    NSLog(@"%@",sender.titleLabel.text);
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    isInMiddleOfInputNumber = false;
    
    
    [ibButton setTitle:@"Bla" forState:UIControlStateNormal];
    
    brain = [[Brain alloc] init];
//    
//    
//    int x = X_POSITION;
//    int y = Y_POSITION;
//    
//    for (int i = 1; i < 10; i++) {
//        UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//        
//        btn.frame = CGRectMake(x,y,64,44);
//        
//        [btn setTitle:[NSString stringWithFormat:@"%d",i] forState:UIControlStateNormal];
//        
//        
//        [self digitPress:nil];
//        
//        
//        
//        [btn addTarget:self action:@selector(digitPress:) forControlEvents:UIControlEventTouchUpInside];
//        
//        
//        
//        [self.view addSubview:btn];
//        
//        x += DISTANCE_X;
//        
//        if (x > X_POSITION+DISTANCE_X*2) {
//            x = X_POSITION;
//            y += DISTANCE_Y;
//        }
//        
//    }
//    
//    
//    x = X_POSITION + DISTANCE_X *3;
//    y = Y_POSITION;
//    
//    NSArray *operations = [NSArray arrayWithObjects:@"+",@"-",@"*",@"/",@"=", nil];
//    
//    for (NSString *operation in operations) {
//        UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//        
//        btn.frame = CGRectMake(x,y,64,44);
//        
//        [btn setTitle:operation forState:UIControlStateNormal];
//        
//        
//        [self digitPress:nil];
//        
//        
//        
//        [btn addTarget:self action:@selector(operationPress:) forControlEvents:UIControlEventTouchUpInside];
//        
//        
//        
//        [self.view addSubview:btn];
//        
//        y += DISTANCE_Y;
//        
//    }
//    
//    
//    display = [[UILabel alloc] initWithFrame:CGRectMake(10, 2, 300, 44)];
//    display.text = @"";
//    display.textAlignment = UITextAlignmentRight;
//    [self.view addSubview:display];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
